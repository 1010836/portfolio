# Chat MFE Build Script
Write-Host "Building Chat MFE..." -ForegroundColor Green

# Install esbuild if not present
if (-not (Get-Command esbuild -ErrorAction SilentlyContinue)) {
    Write-Host "Installing esbuild..." -ForegroundColor Yellow
    npm install -g esbuild
}

# Build the bundle
esbuild src/index.js --bundle --outfile=dist/chat.js --format=iife --global-name=chatMFE

Write-Host "Chat MFE built successfully!" -ForegroundColor Green
Write-Host "Bundle available at: dist/chat.js" -ForegroundColor Cyan