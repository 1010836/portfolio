# Chat MFE Serve Script
Write-Host "Starting Chat MFE server..." -ForegroundColor Green

# Install http-server if not present
if (-not (Get-Command http-server -ErrorAction SilentlyContinue)) {
    Write-Host "Installing http-server..." -ForegroundColor Yellow
    npm install -g http-server
}

# Start the server on port 5002
Write-Host "Serving chat MFE on http://localhost:5002" -ForegroundColor Cyan
Write-Host "Bundle URL: http://localhost:5002/chat.js" -ForegroundColor Yellow
http-server dist -p 5002 --cors