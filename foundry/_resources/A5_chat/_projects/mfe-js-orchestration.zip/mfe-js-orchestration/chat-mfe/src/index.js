import './style.css';

// Chat MFE Implementation
let BASE_PROMPT_SCHEMA = {
  "components": [
    {
      "type": "textarea",
      "key": "prompt",
      "label": "Ask the assistant",
      "rows": 3,
      "autoExpand": true,
      "input": true,
      "validate": { "required": true },
      "className": "mb-2"
    },
    {
      "type": "button",
      "key": "send",
      "label": "<i class=\"bi bi-send\"></i>",
      "action": "submit",
      "theme": "primary",
      "size": "sm"
    }
  ]
};

class ChatMFE {
  constructor() {
    this.chatContainer = null;
  }

  // Clone & create unique keys/ids for forms
  freshSchema(base) {
    const clone = JSON.parse(JSON.stringify(base));
    const suffix = `_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    
    this.mutate(clone.components);
    return clone;
  }

  mutate(arr) {
    (arr || []).forEach(c => {
      if (c.key) c.key += '_' + Date.now().toString(36);
      if (c.id) c.id += '_' + Date.now().toString(36);
      if (c.components) this.mutate(c.components);
      if (Array.isArray(c.columns)) c.columns.forEach(col => this.mutate(col.components));
      if (Array.isArray(c.rows)) c.rows.forEach(row => row.forEach(col => this.mutate(col.components)));
    });
  }

  // Mount a form into a chat bubble
  mountFormBubble(schema, cssClass = 'user') {
    const bubble = document.createElement('div');
    bubble.className = `bubble ${cssClass}`;
    this.chatContainer.appendChild(bubble);
    
    // Ensure the chat scrolls to the bottom
    setTimeout(() => {
      this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
    }, 0);
    
    return window.Formio.createForm(bubble, schema);
  }

  // Start the prompt-submit cycle
  startPromptCycle() {
    this.mountFormBubble(this.freshSchema(BASE_PROMPT_SCHEMA), 'user').then(form => {
      form.on('submit', ({ data }) => {
        const userText = Object.values(data)[0] || '';

        // Replace live form with static user bubble
        const liveRoot = form.element;
        const parent = liveRoot.parentNode;
        const userBubble = document.createElement('div');
        userBubble.className = 'bubble user static';
        userBubble.innerHTML = (userText || '').replace(/\n/g, '<br>');
        parent.replaceChild(userBubble, liveRoot);
        form.destroy(true);

        // Insert AI reply bubble
        const botBubble = document.createElement('div');
        botBubble.className = 'bubble ai';
        botBubble.innerHTML = '🤖 <em>Thinking...</em>';
        if (userBubble.nextSibling) {
          parent.insertBefore(botBubble, userBubble.nextSibling);
        } else {
          parent.appendChild(botBubble);
        }

        // Simulate AI response after 2 seconds
        setTimeout(() => {
          botBubble.innerHTML = `🤖 I received your message: "${userText}". This is a demo response from the chat micro-frontend.`;
        }, 2000);

        // Start next prompt cycle
        this.startPromptCycle();
      });
    }).catch(err => console.error('Form.io render error:', err));
  }

  // Theme management
  setTheme(dark) {
    document.body.classList.toggle('dark-theme', dark);
    const icon = this.chatContainer.parentElement.querySelector('#themeToggle i');
    if (icon) icon.className = dark ? 'bi bi-sun' : 'bi bi-moon';
  }

  saveThemePref(dark) {
    try { localStorage.setItem('chat_theme_dark', dark ? '1' : '0'); } catch {}
  }

  getThemePref() {
    try {
      const pref = localStorage.getItem('chat_theme_dark');
      if (pref === null) return true; // Default to dark
      return pref === '1';
    } catch { return true; }
  }

  // Clear chat functionality
  clearChat() {
    const CONFIRM_CLEAR_SCHEMA = {
      components: [
        {
          type: 'content',
          key: 'confirmText',
          html: '<strong>Are you sure you want to clear the chat?</strong>',
          input: false,
          className: 'mb-2'
        },
        {
          type: 'container',
          key: 'buttonRow',
          components: [
            {
              type: 'button',
              key: 'yes',
              label: 'Yes, clear',
              action: 'event',
              event: 'yesClear',
              theme: 'danger',
              size: 'sm',
              className: 'w-auto m-0'
            },
            {
              type: 'button',
              key: 'cancel',
              label: 'Cancel',
              action: 'event',
              event: 'cancelClear',
              theme: 'secondary',
              size: 'sm',
              className: 'w-auto m-0'
            }
          ]
        }
      ]
    };

    this.mountFormBubble(this.freshSchema(CONFIRM_CLEAR_SCHEMA), 'user').then(form => {
      form.on('customEvent', (evt) => {
        if (evt.type === 'yesClear') {
          this.chatContainer.innerHTML = '';
          this.startPromptCycle();
        }
        // Remove the confirmation bubble
        if (form.element && form.element.parentNode) {
          form.element.parentNode.removeChild(form.element);
        }
        form.destroy(true);
      });
    });
  }

  // Initialize the chat
  init(container) {
    this.chatContainer = container;
    
    // Apply theme
    const dark = this.getThemePref();
    this.setTheme(dark);
    
    // Start the chat cycle
    this.startPromptCycle();
  }
}

// Global functions for micro-frontend orchestration
export function renderChat(domId) {
  const el = document.getElementById(domId);
  
  el.innerHTML = `
    <div class="chat-shell shadow-sm">
      <div id="chat-messages-${domId}" class="chat-scroll" aria-live="polite"></div>
      <div class="theme-toggle-btn d-flex justify-content-center p-3 gap-2">
        <button id="clearChat-${domId}" class="btn btn-outline-danger btn-sm" title="Clear chat">
          <i class="bi bi-trash"></i>
        </button>
        <button id="themeToggle-${domId}" class="btn btn-outline-secondary btn-sm" title="Toggle dark/light mode">
          <i class="bi bi-moon"></i>
        </button>
      </div>
    </div>
  `;

  const chatMFE = new ChatMFE();
  const chatContainer = document.getElementById(`chat-messages-${domId}`);
  
  // Initialize chat
  chatMFE.init(chatContainer);
  
  // Setup event listeners
  const clearBtn = document.getElementById(`clearChat-${domId}`);
  const themeBtn = document.getElementById(`themeToggle-${domId}`);
  
  if (clearBtn) {
    clearBtn.addEventListener('click', () => chatMFE.clearChat());
  }
  
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const isDark = !document.body.classList.contains('dark-theme');
      chatMFE.setTheme(isDark);
      chatMFE.saveThemePref(isDark);
    });
  }

  // Store reference for unmounting
  el._chatMFE = chatMFE;
}

export function unmountChat(domId) {
  const el = document.getElementById(domId);
  if (el._chatMFE) {
    delete el._chatMFE;
  }
  el.innerHTML = '';
}

// Expose globals for the container
window.renderChat = renderChat;
window.unmountChat = unmountChat;