# Header MFE Build Script
Write-Host "Building Header MFE..." -ForegroundColor Green

# Install esbuild if not present
if (-not (Get-Command esbuild -ErrorAction SilentlyContinue)) {
    Write-Host "Installing esbuild..." -ForegroundColor Yellow
    npm install -g esbuild
}

# Build the bundle
esbuild src/index.js --bundle --outfile=dist/header.js --format=iife --global-name=headerMFE

Write-Host "Header MFE built successfully!" -ForegroundColor Green
Write-Host "Bundle available at: dist/header.js" -ForegroundColor Cyan