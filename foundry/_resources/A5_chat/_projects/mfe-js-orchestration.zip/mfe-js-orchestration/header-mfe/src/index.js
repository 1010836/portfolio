import './style.css';

export function renderHeader(domId) {
  const el = document.getElementById(domId);
  el.innerHTML = `
    <header class="mfe-header">
      <h1>🚀 Pulse OS Chat</h1>
      <nav>
        <a href="#/">Home</a>
        <a href="#/chat">Chat</a>
        <a href="#/settings">Settings</a>
      </nav>
    </header>`;
}

export function unmountHeader(domId) {
  const el = document.getElementById(domId);
  el.innerHTML = '';
}

// Expose globals for the container
window.renderHeader = renderHeader;
window.unmountHeader = unmountHeader;