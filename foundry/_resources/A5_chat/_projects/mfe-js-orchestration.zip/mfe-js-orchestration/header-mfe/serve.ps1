# Header MFE Serve Script
Write-Host "Starting Header MFE server..." -ForegroundColor Green

# Install http-server if not present
if (-not (Get-Command http-server -ErrorAction SilentlyContinue)) {
    Write-Host "Installing http-server..." -ForegroundColor Yellow
    npm install -g http-server
}

# Start the server on port 5001
Write-Host "Serving header MFE on http://localhost:5001" -ForegroundColor Cyan
Write-Host "Bundle URL: http://localhost:5001/header.js" -ForegroundColor Yellow
http-server dist -p 5001 --cors