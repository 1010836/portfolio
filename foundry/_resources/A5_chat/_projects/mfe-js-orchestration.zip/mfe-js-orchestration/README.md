# Micro-Frontend JavaScript Orchestration Demo

This project demonstrates a complete micro-frontend implementation using JavaScript orchestration, based on the tutorial patterns. It includes a chat application split into independently deployable micro-frontends.

## 🏗️ Architecture

```
Container (localhost:3000)
├── Header MFE (localhost:5001) - Navigation and branding
└── Chat MFE (localhost:5002) - Full chat functionality with Form.io
```

## 📁 Project Structure

```
mfe-js-orchestration/
├── build-all.ps1           # Master build script
├── start-all.ps1            # Master server start script
├── header-mfe/              # Header micro-frontend
│   ├── src/
│   │   ├── index.js         # Header logic & global functions
│   │   └── style.css        # Header styles
│   ├── dist/                # Built bundles
│   ├── build.ps1            # Build script
│   └── serve.ps1            # Dev server script
├── chat-mfe/                # Chat micro-frontend
│   ├── src/
│   │   ├── index.js         # Chat logic adapted from existing app
│   │   └── style.css        # Chat styles with dark theme
│   ├── dist/                # Built bundles
│   ├── build.ps1            # Build script
│   └── serve.ps1            # Dev server script
└── container/               # Container orchestrator
    ├── index.html           # Main page that loads all MFEs
    └── container.js         # Orchestration logic
```

## 🚀 Quick Start

### 1. Build All Micro-Frontends
```powershell
.\build-all.ps1
```

### 2. Start All Servers
```powershell
.\start-all.ps1
```

### 3. Open Application
Navigate to **http://localhost:3000** in your browser

## 🔧 Individual Commands

### Build Individual MFEs
```powershell
# Header MFE
cd header-mfe
.\build.ps1

# Chat MFE  
cd chat-mfe
.\build.ps1
```

### Start Individual Servers
```powershell
# Header MFE (port 5001)
cd header-mfe
.\serve.ps1

# Chat MFE (port 5002)
cd chat-mfe
.\serve.ps1

# Container (port 3000)
cd container
http-server . -p 3000 --cors
```

## 🎯 Features Implemented

### JavaScript Orchestration Pattern
- ✅ **Global Function Exposure**: Each MFE exposes `render*` and `unmount*` functions
- ✅ **Dynamic Loading**: Container loads MFE bundles at runtime via script tags
- ✅ **Independent Deployment**: Each MFE can be built and deployed separately
- ✅ **Error Handling**: Graceful fallback when MFEs fail to load

### Chat Functionality
- ✅ **Form.io Integration**: Dynamic form rendering for chat prompts
- ✅ **Theme Toggle**: Dark/Light mode with localStorage persistence
- ✅ **Clear Chat**: Confirmation dialog using Form.io components
- ✅ **Auto-scroll**: Chat automatically scrolls to new messages
- ✅ **Responsive Design**: Mobile-friendly chat interface

### Container Orchestration
- ✅ **Parallel Loading**: All MFEs load simultaneously
- ✅ **Status Monitoring**: Real-time loading status display
- ✅ **Debug Tools**: Built-in debugging utilities
- ✅ **Communication Setup**: Inter-MFE event system foundation

## 🌐 URLs & Endpoints

| Service | URL | Purpose |
|---------|-----|---------|
| Container | http://localhost:3000 | Main application |
| Header MFE | http://localhost:5001/header.js | Header bundle |
| Chat MFE | http://localhost:5002/chat.js | Chat bundle |

## 🔍 Development & Debugging

### Browser Developer Tools
- Open DevTools and check the Console for detailed logs
- Network tab shows MFE bundle loading
- Debug info panel (top-right) shows real-time status

### Debug Commands (Browser Console)
```javascript
// Check MFE status
mfeDebug.status()

// Reload the page
mfeDebug.reload()

// Send test events between MFEs
mfeDebug.broadcast('test-event', { message: 'Hello' })
```

## 🎨 Customization

### Adding New Micro-Frontends
1. Create new folder (e.g., `sidebar-mfe/`)
2. Add to `container.js` mfeConfigs array
3. Implement `renderSidebar()` and `unmountSidebar()` functions
4. Create build and serve scripts

### Modifying Existing MFEs
- Edit `src/index.js` and `src/style.css`
- Run `.\build.ps1` to rebuild
- Refresh browser to see changes

## 🛠️ Technologies Used

- **Build Tool**: esbuild (fast ES6+ bundling)
- **Dev Server**: http-server (static file serving with CORS)
- **UI Framework**: Form.io (dynamic form generation)
- **Styling**: Bootstrap 5 + Custom CSS
- **Orchestration**: Vanilla JavaScript (no framework dependencies)

## 📋 Requirements

- **Node.js** (for npm package installation)
- **PowerShell** (Windows 11 compatible)
- **Modern Browser** (Chrome, Firefox, Edge)

## ✅ Implementation Status

This implementation successfully demonstrates:

1. ✅ **Step-by-step procedure** from the JavaScript orchestration tutorial
2. ✅ **Micro-frontend architecture** with independent deployable units  
3. ✅ **Chat functionality** adapted from existing pulse-os app
4. ✅ **PowerShell scripts** for Windows 11 development environment
5. ✅ **Complete working system** ready for testing and extension

The project provides a solid foundation for understanding and extending micro-frontend architectures using JavaScript orchestration patterns.