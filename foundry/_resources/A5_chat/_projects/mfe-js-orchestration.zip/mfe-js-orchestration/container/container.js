// Container Orchestration Script
class MicroFrontendOrchestrator {
    constructor() {
        this.loadedMFEs = new Set();
        this.mfeConfigs = [
            {
                name: 'header',
                url: 'http://localhost:5001/header.js',
                containerId: 'headerContainer',
                renderFunction: 'renderHeader',
                unmountFunction: 'unmountHeader'
            },
            {
                name: 'chat',
                url: 'http://localhost:5002/chat.js',
                containerId: 'chatContainer',
                renderFunction: 'renderChat',
                unmountFunction: 'unmountChat'
            }
        ];
    }

    updateStatus(message) {
        const statusEl = document.getElementById('status');
        if (statusEl) statusEl.textContent = message;
        console.log(`[Container] ${message}`);
    }

    updateMFEStatus(mfeName, status) {
        const statusEl = document.getElementById(`${mfeName}Status`);
        if (statusEl) statusEl.textContent = status;
    }

    showError(containerId, message) {
        const container = document.getElementById(containerId);
        container.innerHTML = `
            <div class="error">
                <h5>❌ Failed to load micro-frontend</h5>
                <p>${message}</p>
                <button class="btn btn-outline-danger btn-sm" onclick="location.reload()">
                    <i class="bi bi-arrow-clockwise"></i> Retry
                </button>
            </div>
        `;
    }

    showSuccess(containerId, mfeName) {
        this.updateMFEStatus(mfeName, 'Loaded ✅');
    }

    async loadScript(url, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            const timeoutId = setTimeout(() => {
                document.head.removeChild(script);
                reject(new Error(`Timeout loading script: ${url}`));
            }, timeout);

            script.onload = () => {
                clearTimeout(timeoutId);
                resolve();
            };

            script.onerror = () => {
                clearTimeout(timeoutId);
                document.head.removeChild(script);
                reject(new Error(`Failed to load script: ${url}`));
            };

            script.src = url;
            script.type = 'text/javascript';
            document.head.appendChild(script);
        });
    }

    async loadMicroFrontend(config) {
        const { name, url, containerId, renderFunction } = config;
        
        try {
            this.updateStatus(`Loading ${name} micro-frontend...`);
            this.updateMFEStatus(name, 'Loading...');

            // Load the MFE script
            await this.loadScript(url);
            
            // Wait a bit for the script to initialize
            await new Promise(resolve => setTimeout(resolve, 100));

            // Check if the render function is available
            if (typeof window[renderFunction] !== 'function') {
                throw new Error(`Render function ${renderFunction} not found on window object`);
            }

            // Render the micro-frontend
            window[renderFunction](containerId);
            
            this.loadedMFEs.add(name);
            this.showSuccess(containerId, name);
            
            console.log(`[Container] Successfully loaded ${name} MFE`);
            
        } catch (error) {
            console.error(`[Container] Failed to load ${name} MFE:`, error);
            this.updateMFEStatus(name, 'Failed ❌');
            this.showError(containerId, `${error.message}. Make sure the ${name} MFE server is running on the correct port.`);
        }
    }

    async loadAllMicroFrontends() {
        this.updateStatus('Initializing micro-frontends...');
        
        // Wait for Form.io to be available
        await this.waitForFormio();
        
        // Load all micro-frontends in parallel
        const loadPromises = this.mfeConfigs.map(config => this.loadMicroFrontend(config));
        
        try {
            await Promise.allSettled(loadPromises);
            
            const successCount = this.loadedMFEs.size;
            const totalCount = this.mfeConfigs.length;
            
            if (successCount === totalCount) {
                this.updateStatus(`All micro-frontends loaded successfully! (${successCount}/${totalCount})`);
            } else {
                this.updateStatus(`Partially loaded: ${successCount}/${totalCount} micro-frontends`);
            }
            
        } catch (error) {
            console.error('[Container] Error loading micro-frontends:', error);
            this.updateStatus('Error loading micro-frontends');
        }
    }

    async waitForFormio(maxWait = 10000) {
        const startTime = Date.now();
        
        while (typeof window.Formio === 'undefined') {
            if (Date.now() - startTime > maxWait) {
                throw new Error('Form.io failed to load within timeout period');
            }
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        console.log('[Container] Form.io is ready');
    }

    unmountAllMicroFrontends() {
        this.mfeConfigs.forEach(config => {
            const { name, containerId, unmountFunction } = config;
            
            if (this.loadedMFEs.has(name) && typeof window[unmountFunction] === 'function') {
                try {
                    window[unmountFunction](containerId);
                    console.log(`[Container] Unmounted ${name} MFE`);
                } catch (error) {
                    console.error(`[Container] Error unmounting ${name} MFE:`, error);
                }
            }
        });
        
        this.loadedMFEs.clear();
    }

    // Communication between micro-frontends
    broadcast(eventName, data) {
        const event = new CustomEvent(`mfe:${eventName}`, {
            detail: { source: 'container', data }
        });
        window.dispatchEvent(event);
        console.log(`[Container] Broadcast event: ${eventName}`, data);
    }

    // Setup inter-MFE communication
    setupCommunication() {
        // Listen for events from micro-frontends
        window.addEventListener('mfe:chat-message', (event) => {
            console.log('[Container] Chat message received:', event.detail);
            // Could forward to other MFEs or handle centrally
        });

        window.addEventListener('mfe:theme-changed', (event) => {
            console.log('[Container] Theme changed:', event.detail);
            // Could sync theme across all MFEs
        });
    }
}

// Initialize the orchestrator when DOM is ready
document.addEventListener('DOMContentLoaded', async function() {
    const orchestrator = new MicroFrontendOrchestrator();
    
    // Setup communication
    orchestrator.setupCommunication();
    
    // Load all micro-frontends
    await orchestrator.loadAllMicroFrontends();
    
    // Setup cleanup on page unload
    window.addEventListener('beforeunload', () => {
        orchestrator.unmountAllMicroFrontends();
    });
    
    // Make orchestrator globally available for debugging
    window.mfeOrchestrator = orchestrator;
    
    console.log('[Container] Micro-frontend orchestration complete');
});

// Utility functions for debugging
window.mfeDebug = {
    reload: () => location.reload(),
    status: () => console.table(window.mfeOrchestrator?.loadedMFEs || []),
    broadcast: (eventName, data) => window.mfeOrchestrator?.broadcast(eventName, data)
};