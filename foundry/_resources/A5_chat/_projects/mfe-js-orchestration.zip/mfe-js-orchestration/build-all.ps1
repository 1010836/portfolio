# Master Build Script - Builds all micro-frontends
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "Building All Micro-Frontends" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan

# Build Header MFE
Write-Host "`n1. Building Header MFE..." -ForegroundColor Yellow
Set-Location "header-mfe"
.\build.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host "Header MFE build failed!" -ForegroundColor Red
    exit 1
}
Set-Location ".."

# Build Chat MFE
Write-Host "`n2. Building Chat MFE..." -ForegroundColor Yellow
Set-Location "chat-mfe"
.\build.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host "Chat MFE build failed!" -ForegroundColor Red
    exit 1
}
Set-Location ".."

Write-Host "`n==================================" -ForegroundColor Green
Write-Host "All micro-frontends built successfully!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green

Write-Host "`nNext steps:" -ForegroundColor Cyan
Write-Host "1. Run .\start-all.ps1 to start all servers" -ForegroundColor White
Write-Host "2. Open http://localhost:3000 to view the container" -ForegroundColor White