# Master Start Script - Starts all micro-frontend servers and container
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "Starting All Micro-Frontend Servers" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan

# Check if http-server is installed
if (-not (Get-Command http-server -ErrorAction SilentlyContinue)) {
    Write-Host "Installing http-server..." -ForegroundColor Yellow
    npm install -g http-server
}

Write-Host "`nStarting servers in background..." -ForegroundColor Yellow

# Start Header MFE server (port 5001)
Write-Host "Starting Header MFE server on port 5001..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\header-mfe'; .\serve.ps1"

# Wait a moment
Start-Sleep -Seconds 2

# Start Chat MFE server (port 5002)
Write-Host "Starting Chat MFE server on port 5002..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\chat-mfe'; .\serve.ps1"

# Wait a moment
Start-Sleep -Seconds 2

# Start Container server (port 3000)
Write-Host "Starting Container server on port 3000..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\container'; http-server . -p 3000 --cors -o"

Write-Host "`n==================================" -ForegroundColor Green
Write-Host "All servers starting..." -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green

Write-Host "`nServer URLs:" -ForegroundColor Cyan
Write-Host "- Header MFE:  http://localhost:5001/header.js" -ForegroundColor White
Write-Host "- Chat MFE:    http://localhost:5002/chat.js" -ForegroundColor White
Write-Host "- Container:   http://localhost:3000" -ForegroundColor Yellow

Write-Host "`nWait a few seconds for all servers to start, then:" -ForegroundColor Cyan
Write-Host "Open http://localhost:3000 in your browser!" -ForegroundColor Yellow

Write-Host "`nPress any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")