const template = document.createElement('template');
template.innerHTML = /*html*/`
  <style>
    :host {
      display: block;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: #fff;
      font: 600 1rem/1.2 'Segoe UI', sans-serif;
      padding: 1rem 2rem;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
    }
    h1 {
      margin: 0;
      font-size: 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .logo {
      font-size: 1.8rem;
    }
    .nav-buttons {
      display: flex;
      gap: 1rem;
    }
    button {
      background: rgba(255,255,255,0.2);
      border: 1px solid rgba(255,255,255,0.3);
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      cursor: pointer;
      font-size: 0.9rem;
      transition: all 0.3s ease;
    }
    button:hover {
      background: rgba(255,255,255,0.3);
      transform: translateY(-1px);
    }
    .status-indicator {
      display: inline-block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #4ade80;
      margin-left: 0.5rem;
    }
  </style>
  <div class="header-content">
    <h1>
      <span class="logo">💬</span>
      Pulse OS Chat
      <span class="status-indicator" id="status"></span>
    </h1>
    <div class="nav-buttons">
      <button id="theme-btn">🌙 Dark Mode</button>
      <button id="clear-btn">🗑️ Clear Chat</button>
    </div>
  </div>
`;

class MfHeader extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({mode: 'open'}).append(template.content.cloneNode(true));
    
    // Bind event handlers
    this.shadowRoot.getElementById('theme-btn').addEventListener('click', () => this.#toggleTheme());
    this.shadowRoot.getElementById('clear-btn').addEventListener('click', () => this.#clearChat());
    
    // Listen for status updates
    window.addEventListener('chat-status', (e) => this.#updateStatus(e.detail));
  }

  #toggleTheme() {
    const currentTheme = document.body.dataset.theme || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    // Dispatch theme change event
    this.dispatchEvent(new CustomEvent('theme-change', {
      detail: { theme: newTheme },
      bubbles: true,
      composed: true
    }));
  }

  #clearChat() {
    // Dispatch clear chat event
    this.dispatchEvent(new CustomEvent('clear-chat', {
      detail: { confirmed: true },
      bubbles: true,
      composed: true
    }));
  }

  #updateStatus(status) {
    const indicator = this.shadowRoot.getElementById('status');
    indicator.style.background = status.connected ? '#4ade80' : '#ef4444';
    indicator.title = status.connected ? 'Connected' : 'Disconnected';
  }
}

customElements.define('mf-header', MfHeader);