const template = document.createElement('template');
template.innerHTML = /*html*/`
  <style>
    :host {
      display: block;
      position: fixed;
      bottom: 1rem;
      right: 1rem;
      z-index: 1000;
      font-family: 'Segoe UI', sans-serif;
    }
    
    .status-card {
      background: var(--status-bg, #ffffff);
      border: 1px solid var(--border-color, #e5e5e5);
      border-radius: 0.5rem;
      padding: 0.75rem 1rem;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      min-width: 150px;
      transition: all 0.3s ease;
      cursor: pointer;
    }
    
    .status-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    }
    
    .status-indicator {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: var(--status-color, #4ade80);
      transition: background 0.3s ease;
      animation: pulse 2s infinite;
    }
    
    .status-text {
      font-size: 0.9rem;
      font-weight: 500;
      color: var(--text-color, #333);
    }
    
    .status-details {
      font-size: 0.75rem;
      color: var(--text-muted, #666);
      margin-top: 0.25rem;
    }
    
    .status-info {
      flex: 1;
    }
    
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
    
    .status-card.connected {
      --status-color: #4ade80;
    }
    
    .status-card.disconnected {
      --status-color: #ef4444;
    }
    
    .status-card.connecting {
      --status-color: #f59e0b;
    }
    
    /* Dark theme */
    :host([data-theme="dark"]) {
      --status-bg: #2d2d2d;
      --border-color: #404040;
      --text-color: #ffffff;
      --text-muted: #cccccc;
    }
    
    /* Hide on mobile */
    @media (max-width: 768px) {
      :host {
        bottom: 0.5rem;
        right: 0.5rem;
      }
      
      .status-card {
        padding: 0.5rem;
        min-width: 120px;
      }
      
      .status-text {
        font-size: 0.8rem;
      }
      
      .status-details {
        font-size: 0.7rem;
      }
    }
  </style>
  
  <div class="status-card connected" id="statusCard">
    <div class="status-indicator" id="indicator"></div>
    <div class="status-info">
      <div class="status-text" id="statusText">Connected</div>
      <div class="status-details" id="statusDetails">Ready to chat</div>
    </div>
  </div>
`;

class MfStatus extends HTMLElement {
  #connectionState = 'connecting';
  #lastUpdate = Date.now();
  #messageCount = 0;
  
  constructor() {
    super();
    this.attachShadow({mode: 'open'}).append(template.content.cloneNode(true));
    
    // Get DOM elements
    this.statusCard = this.shadowRoot.getElementById('statusCard');
    this.statusText = this.shadowRoot.getElementById('statusText');
    this.statusDetails = this.shadowRoot.getElementById('statusDetails');
    
    // Bind event handlers
    this.statusCard.addEventListener('click', () => this.#toggleDetails());
    
    // Listen for events from other components
    window.addEventListener('chat-status', (e) => this.#updateConnectionStatus(e.detail));
    window.addEventListener('message-sent', (e) => this.#incrementMessageCount(e.detail));
    window.addEventListener('theme-change', (e) => this.#handleThemeChange(e.detail));
    
    // Initialize status
    this.#setStatus('connecting', 'Initializing...', 'Setting up connection');
    
    // Simulate initial connection
    setTimeout(() => {
      this.#setStatus('connected', 'Connected', 'Ready to chat');
    }, 2000);
  }
  
  #setStatus(state, text, details) {
    this.#connectionState = state;
    this.#lastUpdate = Date.now();
    
    // Update visual state
    this.statusCard.className = `status-card ${state}`;
    this.statusText.textContent = text;
    this.statusDetails.textContent = details;
    
    // Dispatch status change event
    this.dispatchEvent(new CustomEvent('status-change', {
      detail: { state, text, details, timestamp: this.#lastUpdate },
      bubbles: true,
      composed: true
    }));
  }
  
  #updateConnectionStatus(statusData) {
    if (statusData.connected) {
      this.#setStatus('connected', 'Connected', `Ready • ${this.#messageCount} messages`);
    } else {
      this.#setStatus('disconnected', 'Disconnected', 'Connection lost');
    }
  }
  
  #incrementMessageCount(messageData) {
    this.#messageCount++;
    if (this.#connectionState === 'connected') {
      this.statusDetails.textContent = `Ready • ${this.#messageCount} messages`;
    }
  }
  
  #toggleDetails() {
    const now = Date.now();
    const uptime = Math.floor((now - this.#lastUpdate) / 1000);
    const uptimeText = uptime < 60 ? `${uptime}s` : `${Math.floor(uptime / 60)}m`;
    
    // Toggle between basic and detailed view
    const isDetailed = this.statusDetails.textContent.includes('Uptime');
    
    if (isDetailed) {
      // Show basic info
      this.statusDetails.textContent = this.#connectionState === 'connected' 
        ? `Ready • ${this.#messageCount} messages`
        : 'Connection lost';
    } else {
      // Show detailed info
      this.statusDetails.textContent = `Uptime: ${uptimeText} • Messages: ${this.#messageCount}`;
    }
  }
  
  #handleThemeChange(themeData) {
    this.setAttribute('data-theme', themeData.theme);
  }
  
  // Public method to simulate connection issues (for testing)
  simulateDisconnection() {
    this.#setStatus('disconnected', 'Disconnected', 'Connection lost');
    
    // Reconnect after 3 seconds
    setTimeout(() => {
      this.#setStatus('connecting', 'Reconnecting...', 'Attempting to reconnect');
      setTimeout(() => {
        this.#setStatus('connected', 'Connected', `Ready • ${this.#messageCount} messages`);
      }, 2000);
    }, 3000);
  }
}

customElements.define('mf-status', MfStatus);