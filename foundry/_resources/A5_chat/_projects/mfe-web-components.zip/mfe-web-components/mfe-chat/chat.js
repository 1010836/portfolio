const template = document.createElement('template');
template.innerHTML = /*html*/`
  <style>
    :host {
      display: block;
      padding: 1rem;
      font-family: 'Segoe UI', sans-serif;
      height: calc(100vh - 200px);
      background: var(--chat-bg, #ffffff);
      color: var(--chat-text, #333333);
      transition: all 0.3s ease;
    }
    
    .chat-container {
      display: flex;
      flex-direction: column;
      height: 100%;
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid var(--border-color, #e5e5e5);
      border-radius: 1rem;
      overflow: hidden;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    
    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 1rem;
      background: var(--messages-bg, #f8f9fa);
      scroll-behavior: smooth;
    }
    
    .message {
      margin-bottom: 1rem;
      padding: 0.75rem 1rem;
      border-radius: 1rem;
      max-width: 80%;
      word-wrap: break-word;
    }
    
    .message.user {
      background: var(--user-msg-bg, #007bff);
      color: white;
      margin-left: auto;
      text-align: right;
    }
    
    .message.assistant {
      background: var(--assistant-msg-bg, #e9ecef);
      color: var(--assistant-msg-text, #333);
      margin-right: auto;
    }
    
    .message.system {
      background: var(--system-msg-bg, #28a745);
      color: white;
      margin: 0 auto;
      text-align: center;
      font-size: 0.9rem;
      max-width: 60%;
    }
    
    .chat-input-area {
      padding: 1rem;
      background: var(--input-area-bg, #ffffff);
      border-top: 1px solid var(--border-color, #e5e5e5);
    }
    
    .input-group {
      display: flex;
      gap: 0.5rem;
      align-items: end;
    }
    
    #messageInput {
      flex: 1;
      padding: 0.75rem;
      border: 1px solid var(--border-color, #ddd);
      border-radius: 0.5rem;
      font-size: 1rem;
      resize: vertical;
      min-height: 44px;
      max-height: 120px;
      background: var(--input-bg, #ffffff);
      color: var(--input-text, #333);
    }
    
    #sendBtn {
      background: var(--send-btn-bg, #007bff);
      color: white;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 0.5rem;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
      min-height: 44px;
    }
    
    #sendBtn:hover:not(:disabled) {
      background: var(--send-btn-hover, #0056b3);
    }
    
    #sendBtn:disabled {
      background: var(--disabled-bg, #6c757d);
      cursor: not-allowed;
    }
    
    .typing-indicator {
      display: none;
      padding: 0.75rem 1rem;
      background: var(--assistant-msg-bg, #e9ecef);
      border-radius: 1rem;
      margin-right: auto;
      max-width: 80%;
      margin-bottom: 1rem;
    }
    
    .typing-dots {
      display: inline-flex;
      gap: 0.25rem;
    }
    
    .typing-dots span {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--typing-dot, #666);
      animation: typing 1.5s infinite;
    }
    
    .typing-dots span:nth-child(2) { animation-delay: 0.2s; }
    .typing-dots span:nth-child(3) { animation-delay: 0.4s; }
    
    @keyframes typing {
      0%, 60%, 100% { opacity: 0.3; }
      30% { opacity: 1; }
    }
    
    /* Dark theme variables */
    :host([data-theme="dark"]) {
      --chat-bg: #1a1a1a;
      --chat-text: #ffffff;
      --border-color: #404040;
      --messages-bg: #2d2d2d;
      --user-msg-bg: #0d6efd;
      --assistant-msg-bg: #404040;
      --assistant-msg-text: #ffffff;
      --system-msg-bg: #198754;
      --input-area-bg: #2d2d2d;
      --input-bg: #404040;
      --input-text: #ffffff;
      --send-btn-bg: #0d6efd;
      --send-btn-hover: #0a58ca;
      --disabled-bg: #6c757d;
      --typing-dot: #cccccc;
    }
  </style>
  
  <div class="chat-container">
    <div class="chat-messages" id="messages"></div>
    <div class="typing-indicator" id="typingIndicator">
      <div class="typing-dots">
        <span></span><span></span><span></span>
      </div>
      Assistant is typing...
    </div>
    <div class="chat-input-area">
      <div class="input-group">
        <textarea 
          id="messageInput" 
          placeholder="Type your message here..." 
          rows="1"
          maxlength="4000"
        ></textarea>
        <button id="sendBtn">Send</button>
      </div>
    </div>
  </div>
`;

class MfChat extends HTMLElement {
  #messages = [];
  #isTyping = false;
  
  constructor() {
    super();
    this.attachShadow({mode: 'open'}).append(template.content.cloneNode(true));
    
    // Get DOM elements
    this.messagesContainer = this.shadowRoot.getElementById('messages');
    this.messageInput = this.shadowRoot.getElementById('messageInput');
    this.sendBtn = this.shadowRoot.getElementById('sendBtn');
    this.typingIndicator = this.shadowRoot.getElementById('typingIndicator');
    
    // Bind event handlers
    this.sendBtn.addEventListener('click', () => this.#sendMessage());
    this.messageInput.addEventListener('keydown', (e) => this.#handleKeyDown(e));
    this.messageInput.addEventListener('input', () => this.#adjustTextareaHeight());
    
    // Listen for external events
    window.addEventListener('theme-change', (e) => this.#handleThemeChange(e.detail));
    window.addEventListener('clear-chat', () => this.#clearMessages());
    
    // Initialize with welcome message
    this.#addMessage('system', 'Welcome to Pulse OS Chat! How can I help you today?');
    this.#updateStatus(true);
  }
  
  #handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.#sendMessage();
    }
  }
  
  #adjustTextareaHeight() {
    const textarea = this.messageInput;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  }
  
  #sendMessage() {
    const message = this.messageInput.value.trim();
    if (!message || this.#isTyping) return;
    
    // Add user message
    this.#addMessage('user', message);
    this.messageInput.value = '';
    this.#adjustTextareaHeight();
    
    // Simulate assistant response
    this.#simulateAssistantResponse(message);
  }
  
  #addMessage(type, content) {
    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.textContent = content;
    
    this.messagesContainer.appendChild(messageEl);
    this.#messages.push({ type, content, timestamp: Date.now() });
    
    // Auto-scroll to bottom
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    
    // Dispatch message event for analytics
    this.dispatchEvent(new CustomEvent('message-sent', {
      detail: { type, content },
      bubbles: true,
      composed: true
    }));
  }
  
  #simulateAssistantResponse(userMessage) {
    this.#setTyping(true);
    
    // Simulate network delay
    setTimeout(() => {
      const responses = [
        "I understand you're asking about: " + userMessage.slice(0, 50) + "...",
        "That's an interesting question! Let me help you with that.",
        "Based on your message, here's what I can tell you...",
        "I'm processing your request about: " + userMessage.toLowerCase(),
        "Thanks for your message! Here's my response to your inquiry."
      ];
      
      const response = responses[Math.floor(Math.random() * responses.length)];
      this.#addMessage('assistant', response);
      this.#setTyping(false);
    }, 1500 + Math.random() * 2000);
  }
  
  #setTyping(isTyping) {
    this.#isTyping = isTyping;
    this.sendBtn.disabled = isTyping;
    this.typingIndicator.style.display = isTyping ? 'block' : 'none';
    
    if (isTyping) {
      this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }
  }
  
  #clearMessages() {
    this.messagesContainer.innerHTML = '';
    this.#messages = [];
    this.#addMessage('system', 'Chat cleared. How can I help you?');
  }
  
  #handleThemeChange(themeData) {
    this.setAttribute('data-theme', themeData.theme);
    document.body.dataset.theme = themeData.theme;
    
    // Update theme button text
    const themeText = themeData.theme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';
    
    // Dispatch event to update header
    this.dispatchEvent(new CustomEvent('theme-updated', {
      detail: { theme: themeData.theme, buttonText: themeText },
      bubbles: true,
      composed: true
    }));
  }
  
  #updateStatus(connected) {
    // Dispatch status update event
    this.dispatchEvent(new CustomEvent('chat-status', {
      detail: { connected },
      bubbles: true,
      composed: true
    }));
  }
  
  connectedCallback() {
    // Component mounted - simulate connection
    setTimeout(() => this.#updateStatus(true), 1000);
  }
}

customElements.define('mf-chat', MfChat);