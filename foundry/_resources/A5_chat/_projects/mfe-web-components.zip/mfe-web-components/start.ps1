# Pulse OS Chat - Web Components Micro-Frontend Start Script
# Windows 11 PowerShell Script

Write-Host "Starting Pulse OS Chat - Web Components Micro-Frontend" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray

# Check if Node.js is installed
try {
    $nodeVersion = node --version
    Write-Host "Node.js detected: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "Node.js not found. Please install Node.js 18+ and try again." -ForegroundColor Red
    Write-Host "Download from: https://nodejs.org/" -ForegroundColor Yellow
    pause
    exit 1
}

# Check if http-server is installed
$httpServerInstalled = $false
try {
    $httpServerVersion = npx http-server --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $httpServerVersion) {
        Write-Host "http-server available: $httpServerVersion" -ForegroundColor Green
        $httpServerInstalled = $true
    }
} catch {
    Write-Host "http-server not found, will install..." -ForegroundColor Yellow
}

# Install dependencies if needed
if (-not $httpServerInstalled) {
    Write-Host "Installing dependencies..." -ForegroundColor Blue
    npm install --silent
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Dependencies installed successfully" -ForegroundColor Green
    } else {
        Write-Host "Failed to install dependencies" -ForegroundColor Red
        pause
        exit 1
    }
}

Write-Host ""
Write-Host "Starting development server..." -ForegroundColor Blue
Write-Host "   Server will start on: http://localhost:8080" -ForegroundColor Yellow
Write-Host "   Container app URL: http://localhost:8080/container/" -ForegroundColor Yellow
Write-Host ""
Write-Host "Debug tools available in browser console as 'pulseDebug'" -ForegroundColor Magenta
Write-Host "   Example: pulseDebug.status(), pulseDebug.toggleTheme()" -ForegroundColor Gray
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Red
Write-Host "=" * 60 -ForegroundColor Gray

# Start the server with CORS enabled
try {
    npx http-server . -p 8080 --cors -o -c-1 -d false
} catch {
    Write-Host "Failed to start server: $($_.Exception.Message)" -ForegroundColor Red
    pause
    exit 1
}

Write-Host ""
Write-Host "Server stopped. Thanks for using Pulse OS Chat!" -ForegroundColor Cyan