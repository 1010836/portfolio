const HtmlWebpackPlugin = require('html-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container;

module.exports = {
  mode: 'development',
  entry: './src/index.js',
  devServer: { port: 3000, static: false },
  output: { publicPath: 'auto', uniqueName: 'shell' },
  plugins: [
    new ModuleFederationPlugin({
      name: 'shell',
      remotes: {
        // localAlias : globalName@url
        remote: 'remote@http://localhost:3001/remoteEntry.js',
      },
      shared: {},
    }),
    new HtmlWebpackPlugin({ template: './public/index.html' }),
  ],
};