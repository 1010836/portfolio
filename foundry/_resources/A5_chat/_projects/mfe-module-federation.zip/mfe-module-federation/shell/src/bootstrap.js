(async () => {
  // Dynamic import pulls the exposed module from the remote
  const { default: renderButton } = await import('remote/renderButton');
  renderButton('host-root');
})();