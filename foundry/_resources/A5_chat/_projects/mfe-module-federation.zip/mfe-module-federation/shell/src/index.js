// Async boundary keeps initial chunk small – recommended by webpack docs
import('./bootstrap');