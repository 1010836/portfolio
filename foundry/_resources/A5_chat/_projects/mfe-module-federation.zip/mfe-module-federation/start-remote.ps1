#!/usr/bin/env pwsh
Write-Host "Starting Remote MFE on port 3001..." -ForegroundColor Green
Set-Location remote
npx webpack serve --config webpack.remote.config.js