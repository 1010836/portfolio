#!/usr/bin/env pwsh
Write-Host "Starting Shell Host on port 3000..." -ForegroundColor Green
Set-Location shell
npx webpack serve --config webpack.shell.config.js