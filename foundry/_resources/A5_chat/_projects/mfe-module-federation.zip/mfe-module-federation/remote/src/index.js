// give the host a stable API
import renderButton from './button.js';
window.renderRemoteButton = renderButton;