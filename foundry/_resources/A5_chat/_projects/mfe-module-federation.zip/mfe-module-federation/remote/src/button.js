export default function renderButton(targetId) {
  const btn = document.createElement('button');
  btn.textContent = 'Remote Button';
  btn.onclick = () => alert('Hello from the remote MFE!');
  document.getElementById(targetId).appendChild(btn);
}