const HtmlWebpackPlugin = require('html-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container;

module.exports = {
  mode: 'development',
  entry: './src/index.js',
  devServer: { port: 3001, static: false },
  output: {
    publicPath: 'auto',         // lets webpack figure it out at runtime
    uniqueName: 'remote',       // prevents runtime collisions
  },
  plugins: [
    new ModuleFederationPlugin({
      name: 'remote',                // global var in remoteEntry.js
      filename: 'remoteEntry.js',    // the file the host will load
      exposes: {
        './renderButton': './src/button.js',  // key = public path
      },
      shared: {},                    // nothing to share in pure JS
    }),
    new HtmlWebpackPlugin({ template: './public/index.html' }),
  ],
};