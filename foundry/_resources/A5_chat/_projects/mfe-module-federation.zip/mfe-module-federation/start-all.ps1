#!/usr/bin/env pwsh
Write-Host "Starting Module Federation Demo..." -ForegroundColor Cyan
Write-Host "This will start both Remote (port 3001) and Shell (port 3000)" -ForegroundColor Yellow

# Start Remote MFE in background
Write-Host "Starting Remote MFE..." -ForegroundColor Green
Start-Process pwsh -ArgumentList "-Command", "cd '$PWD\remote'; npx webpack serve --config webpack.remote.config.js" -WindowStyle Normal

# Wait a moment for remote to initialize
Start-Sleep -Seconds 3

# Start Shell Host
Write-Host "Starting Shell Host..." -ForegroundColor Green
Write-Host "Shell will be available at: http://localhost:3000" -ForegroundColor Magenta
Write-Host "Remote will be available at: http://localhost:3001" -ForegroundColor Magenta

Set-Location shell
npx webpack serve --config webpack.shell.config.js