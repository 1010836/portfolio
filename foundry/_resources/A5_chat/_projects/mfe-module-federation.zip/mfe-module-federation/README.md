# Module Federation Demo

This project demonstrates Webpack 5 Module Federation with vanilla JavaScript, creating a micro-frontend architecture with a host/shell application and a remote micro-frontend.

## Architecture

- **Shell/Host** (port 3000): The main application that consumes remote micro-frontends
- **Remote** (port 3001): A micro-frontend that exposes a button component

## Project Structure

```
mfe-module-federation/
├── package.json                    # Main dependencies and scripts
├── start-all.ps1                   # PowerShell script to start both apps
├── start-remote.ps1                # PowerShell script for remote only
├── start-shell.ps1                 # PowerShell script for shell only
├── remote/                         # Remote micro-frontend
│   ├── src/
│   │   ├── index.js               # Remote entry point
│   │   └── button.js              # Button component
│   ├── public/
│   │   └── index.html             # Remote HTML template
│   └── webpack.remote.config.js   # Remote webpack config
└── shell/                          # Shell/Host application
    ├── src/
    │   ├── index.js               # Shell entry point (async boundary)
    │   └── bootstrap.js           # Main shell logic
    ├── public/
    │   └── index.html             # Shell HTML template
    └── webpack.shell.config.js    # Shell webpack config
```

## How to Run

### Option 1: Start Both Applications (Recommended)
```powershell
.\start-all.ps1
```

### Option 2: Start Applications Separately
```powershell
# Terminal 1 - Start Remote MFE
.\start-remote.ps1

# Terminal 2 - Start Shell Host (after remote is running)
.\start-shell.ps1
```

### Option 3: Using npm scripts
```powershell
# Terminal 1
npm run start:remote

# Terminal 2
npm run start:shell
```

## Access the Applications

- **Shell/Host**: http://localhost:3000
- **Remote MFE**: http://localhost:3001

## How Module Federation Works

1. **Remote Application** exposes a button component via `ModuleFederationPlugin`
2. **Shell Application** consumes the remote component dynamically at runtime
3. **Webpack** handles the federation orchestration and loading
4. **Async Boundary** pattern ensures optimal chunk loading

## Key Features

- ✅ Runtime composition (no build-time coupling)
- ✅ Independent deployments
- ✅ Technology agnostic (vanilla JS)
- ✅ PowerShell automation scripts for Windows
- ✅ Development server hot reloading

## Technical Details

- **Webpack 5** Module Federation
- **Vanilla JavaScript** (no frameworks)
- **Development servers** on ports 3000/3001
- **Async loading** with dynamic imports
- **Windows PowerShell** automation