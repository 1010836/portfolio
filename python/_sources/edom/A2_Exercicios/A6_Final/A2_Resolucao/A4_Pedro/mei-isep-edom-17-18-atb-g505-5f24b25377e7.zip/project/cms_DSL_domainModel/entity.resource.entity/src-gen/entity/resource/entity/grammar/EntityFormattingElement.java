/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity.grammar;

public abstract class EntityFormattingElement extends entity.resource.entity.grammar.EntitySyntaxElement {
	
	public EntityFormattingElement(entity.resource.entity.grammar.EntityCardinality cardinality) {
		super(cardinality, null);
	}
	
}
