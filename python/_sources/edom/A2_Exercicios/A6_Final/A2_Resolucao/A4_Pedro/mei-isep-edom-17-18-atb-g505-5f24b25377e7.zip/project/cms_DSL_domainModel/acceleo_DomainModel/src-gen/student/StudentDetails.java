package student;

public class StudentDetails {
  
   	private String id;

	private String displayName;

}
