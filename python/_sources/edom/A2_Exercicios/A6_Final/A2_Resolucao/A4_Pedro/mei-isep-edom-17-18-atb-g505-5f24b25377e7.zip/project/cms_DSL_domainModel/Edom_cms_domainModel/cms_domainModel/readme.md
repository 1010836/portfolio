# e5emftext Project

This Eclipse project should be used as the base project for the EDOM exercise 5.
