/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity.ui;

/**
 * This class is only generated for backwards compatiblity. The original contents
 * of this class have been moved to class
 * entity.resource.entity.mopp.EntityAntlrTokenHelper.
 */
public class EntityAntlrTokenHelper {
	// This class is intentionally left empty.
}
