package student;

public class StudentsPresenter {
	
	public interface Display {

	}

	public void deleteSelectedStudent() {

	}
}
