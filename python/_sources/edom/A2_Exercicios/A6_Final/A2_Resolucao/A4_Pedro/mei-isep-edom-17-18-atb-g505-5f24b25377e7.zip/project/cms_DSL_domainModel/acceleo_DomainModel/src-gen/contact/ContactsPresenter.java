package contact;

public class ContactsPresenter {
	
	public interface Display {

	}

	public void deleteSelectedContact() {

	}
}
