/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity.grammar;

public enum EntityCardinality {
	
	ONE, PLUS, QUESTIONMARK, STAR;
	
}
