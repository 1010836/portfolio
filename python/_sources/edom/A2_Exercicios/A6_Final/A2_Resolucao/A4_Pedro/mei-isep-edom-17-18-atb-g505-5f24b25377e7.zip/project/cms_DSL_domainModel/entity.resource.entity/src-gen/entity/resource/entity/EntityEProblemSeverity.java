/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity;

public enum EntityEProblemSeverity {
	WARNING, ERROR;
}
