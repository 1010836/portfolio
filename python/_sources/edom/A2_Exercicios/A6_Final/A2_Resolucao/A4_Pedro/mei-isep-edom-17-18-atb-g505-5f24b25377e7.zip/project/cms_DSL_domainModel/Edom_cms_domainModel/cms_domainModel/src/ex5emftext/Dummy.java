package ex5emftext;

// To avoid Eclipse problem with prjects that do not have the "src" folder
public class Dummy {

}
