# Project

You should use this folder for the development of the project (both ODSOFT and EDOM).
The project will use a Web Application developed with GWT. Later on, teachers will provide an initial version of this application (in the form of an Eclipse project) that you should copy into this folder.
