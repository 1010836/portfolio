package student;

public class Student {
    private String name;

	private ArrayList<Contact> contacts;

	private StudentDetails details;

	public StudentDetails getLightWeightStudent() {
		return details;
	}

}
