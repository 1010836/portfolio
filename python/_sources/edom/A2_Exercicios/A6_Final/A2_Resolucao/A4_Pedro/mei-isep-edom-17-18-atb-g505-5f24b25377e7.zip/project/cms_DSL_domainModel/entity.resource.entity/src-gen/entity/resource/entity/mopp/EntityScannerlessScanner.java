/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity.mopp;

/**
 * This empty class was generated to overwrite exiting classes.
 */
public class EntityScannerlessScanner {
}
