/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity;

public interface IEntityInterpreterListener {
	
	public void handleInterpreteObject(org.eclipse.emf.ecore.EObject element);
}
