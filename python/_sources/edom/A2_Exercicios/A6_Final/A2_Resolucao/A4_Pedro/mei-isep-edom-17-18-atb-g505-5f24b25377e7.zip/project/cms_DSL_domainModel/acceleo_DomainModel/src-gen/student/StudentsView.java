package student;

public class StudentsView implements StudentsPresenter.Display {
	
}
