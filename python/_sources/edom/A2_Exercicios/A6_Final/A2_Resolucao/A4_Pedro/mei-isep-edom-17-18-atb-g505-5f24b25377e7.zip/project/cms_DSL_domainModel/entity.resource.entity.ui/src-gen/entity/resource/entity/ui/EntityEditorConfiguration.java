/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity.ui;

/**
 * This class is deprecated and not used as of EMFText 1.4.1. The original
 * contents of this class have been moved to
 * entity.resource.entity.ui.EntitySourceViewerConfiguration. This class is only
 * generated to avoid compile errors with existing versions of this class.
 */
@Deprecated
public class EntityEditorConfiguration {
	
}
