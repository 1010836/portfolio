package contact;

public class ContactsView implements ContactsPresenter.Display {
	
}
