package contact;

public class ContactDetails {
  
   	private String id;

	private String displayName;

}
