/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package entity.resource.entity.ui;

/**
 * An enumeration of all position categories.
 */
public enum EntityPositionCategory {
	BRACKET, DEFINTION, PROXY;
}
